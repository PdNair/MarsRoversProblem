﻿namespace MarsRoversProblem
{
    public enum Directions
    {
        North,
        South,
        East,
        West
    }
}
